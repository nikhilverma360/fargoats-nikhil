package main

import (
	"log"
	"os"

	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

var DB *gorm.DB

func ConnectDatabase() {

	// dsn := "host=aws-0-us-west-1.pooler.supabase.com user=postgres.dxhmpwhtvzvhwznqswek password=w6CEH4DFrceDkQVI dbname=your_db port=6543 sslmode=disable"
	dsn := os.Getenv("DATABASE_URL")
	// dsn := "host=localhost user=your_user password=your_password dbname=your_db port=5432 sslmode=disable"

	db, err := gorm.Open(postgres.Open(dsn), &gorm.Config{})
	if err != nil {
		log.Fatalf("Failed to connect to database: %v", err)
	}

	// Migrate the schema
	err = db.AutoMigrate(&Profile{}, &Project{}) // Add other models as needed
	if err != nil {
		log.Fatalf("Failed to migrate database: %v", err)
	}

	DB = db
	log.Println("Database connection established")
}
