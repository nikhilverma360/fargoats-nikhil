package main

import (
	"bytes"
	"encoding/json"
	"net/http"

	"github.com/gin-gonic/gin"
)

func CreateProfile(c *gin.Context) {
	var input Profile
	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// Prepare the data to be sent to Supabase
	data := map[string]interface{}{
		"user_id":        input.UserID,
		"email":          input.Email,
		"wallet_address": input.WalletAddress,
		"unique_name":    input.UniqueName,
		"id":             input.ID,
	}

	jsonData, err := json.Marshal(data)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to marshal JSON"})
		return
	}

	// Make the POST request to Supabase
	req, err := http.NewRequest("POST", "https://dxhmpwhtvzvhwznqswek.supabase.co/rest/v1/profiles", bytes.NewBuffer(jsonData))
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to create request"})
		return
	}

	req.Header.Set("apikey", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImR4aG1wd2h0dnp2aHd6bnFzd2VrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzA2ODg5OTksImV4cCI6MjA0NjI2NDk5OX0.dKT3nNRhEuU4TsEhXUgMfDHbEDU-TYt6v0cTf0ZQ2CY")               // Replace with your actual API key
	req.Header.Set("Authorization", "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImR4aG1wd2h0dnp2aHd6bnFzd2VrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzA2ODg5OTksImV4cCI6MjA0NjI2NDk5OX0.dKT3nNRhEuU4TsEhXUgMfDHbEDU-TYt6v0cTf0ZQ2CY") // Replace with your actual bearer token
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Prefer", "return=minimal")

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to send request to Supabase"})
		return
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusCreated {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to create profile in Supabase"})
		return
	}

	c.JSON(http.StatusOK, input)
}

func GetProfile(c *gin.Context) {
	var profile Profile
	id := c.Param("id")

	if err := DB.First(&profile, "id = ?", id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Profile not found"})
		return
	}

	c.JSON(http.StatusOK, profile)
}

// Implement other handlers as needed
