package main

import (
	"bytes"
	"encoding/json"
	"net/http"

	"github.com/gin-gonic/gin"
)

type Profile struct {
	ID            string `json:"id"`
	UserID        string `json:"user_id"`
	Email         string `json:"email"`
	WalletAddress string `json:"wallet_address"`
	UniqueName    string `json:"unique_name"`
}

func main() {
	r := gin.Default()

	r.POST("/profiles", createProfile)

	r.Run(":6666")
}

func createProfile(c *gin.Context) {
	var input Profile
	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// Prepare the data to be sent to Supabase
	data := map[string]interface{}{
		"user_id":        input.UserID,
		"email":          input.Email,
		"wallet_address": input.WalletAddress,
		"unique_name":    input.UniqueName,
		"id":             input.ID,
	}

	jsonData, err := json.Marshal(data)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to marshal JSON"})
		return
	}

	// Make the POST request to Supabase
	req, err := http.NewRequest("POST", "https://dxhmpwhtvzvhwznqswek.supabase.co/rest/v1/profiles", bytes.NewBuffer(jsonData))
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to create request"})
		return
	}

	req.Header.Set("apikey", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImR4aG1wd2h0dnp2aHd6bnFzd2VrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzA2ODg5OTksImV4cCI6MjA0NjI2NDk5OX0.dKT3nNRhEuU4TsEhXUgMfDHbEDU-TYt6v0cTf0ZQ2CY")               // Replace with your actual API key
	req.Header.Set("Authorization", "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImR4aG1wd2h0dnp2aHd6bnFzd2VrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzA2ODg5OTksImV4cCI6MjA0NjI2NDk5OX0.dKT3nNRhEuU4TsEhXUgMfDHbEDU-TYt6v0cTf0ZQ2CY") // Replace with your actual bearer token
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Prefer", "return=minimal;resolution=merge-duplicates")

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to send request to Supabase"})
		return
	}
	defer resp.Body.Close()

	// Check for non-2xx status codes
	if resp.StatusCode != http.StatusCreated {
		var errorResponse map[string]interface{}
		if err := json.NewDecoder(resp.Body).Decode(&errorResponse); err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to read error response"})
			return
		}
		c.JSON(resp.StatusCode, errorResponse) // Return the error response from Supabase
		return
	}

	c.JSON(http.StatusOK, input)
}
